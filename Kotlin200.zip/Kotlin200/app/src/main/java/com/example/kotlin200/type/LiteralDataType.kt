package com.example.kotlin200

//리터럴의 타입
fun main(){
    //변수에 값을 저장하려면 변수의 타입과 저장하려는 표현식의 타입이 같아야 한다.
    val variable = 10+12-5
    println(variable)
}