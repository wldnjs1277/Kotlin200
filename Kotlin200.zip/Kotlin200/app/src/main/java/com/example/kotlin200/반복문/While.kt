package com.example.kotlin200

//반복문 - while

fun main(){
    var i=1
    while(i<10){
        println(i)
        i++
    }
//반복문 do-while
    var a = 1
    do{
        println("실행됨$a")
        a++
    }while (a<10)
}