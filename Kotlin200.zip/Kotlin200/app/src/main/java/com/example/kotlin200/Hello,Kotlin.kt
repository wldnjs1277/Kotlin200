package com.example.kotlin200
//프로그램은 항상 main 함수로 부터 시작된다.
fun main(){
    //println은 화면에 텍스트를 출력하는 함수
    //코틀린에 기본적으로 내장되어 있는 함수이다.
    println("hello kotlin!")
}