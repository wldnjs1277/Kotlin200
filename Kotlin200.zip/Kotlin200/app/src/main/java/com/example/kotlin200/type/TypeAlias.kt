package com.example.kotlin200

//타입 별명 (TypeAlias)
//typealias라는 키워드를 사용하면 이미존재하는 타입에 별명을 붙일 수 있다.
typealias Number = Int
fun main(){
    val a:Number=10
    println(a)

}