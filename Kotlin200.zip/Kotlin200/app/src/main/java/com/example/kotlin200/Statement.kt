package com.example.kotlin200

//statement
//statement(문장)은 독립적으로 실행할 수 있는 코틀린 코드 를 뜻한다.
//문장은 독립적인 코드 조각을 새는 단위이기 때문에 표현식과는 조금 다르다.
fun main(){
    val num:Int//첫번째 문장
    num=15//두번째 문장

    println(num+7*3)//3번째 문장
}