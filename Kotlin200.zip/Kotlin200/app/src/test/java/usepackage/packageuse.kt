package usepackage

import com.example.kotlin200.test //import를 이용하여 다른 패키지에 있는 함수 사용가능

//다른 패키지에 있는 함수 사용하기


fun main(){
    test()
}